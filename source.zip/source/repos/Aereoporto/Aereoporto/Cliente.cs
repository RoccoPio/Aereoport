﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aereoporto
{
    internal class Cliente
    {
        public long idcliente;
        public string username;
        public string password;
        public string nome;
        public string cognome;
        public string sesso;

        public Cliente(long idcliente, string username, string password, string nome, string cognome, string sesso)
        {
            this.idcliente = idcliente;
            this.username = username;
            this.password = password;
            this.nome = nome;
            this.cognome = cognome;
            this.sesso = sesso;
        }

        public Cliente(string username, string password, string nome, string cognome, string sesso)
        {
            this.username = username;
            this.password = password;
            this.nome = nome;
            this.cognome = cognome;
            this.sesso = sesso;
        }

        const string CONNECTION_STRING = "Server=LAPTOP-VC79DN9U\\MSSQLSERVER01;Initial Catalog=db_aereoC; Trusted_Connection=True";
        SqlConnection conn = new SqlConnection(CONNECTION_STRING);
        
        public void signup(Cliente u)
        {
      

            try
            {
                conn.Open();
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "INSERT INTO Cliente (Username, Password, Nome, Cognome, Sesso) VALUES (@Username, @Password, @Nome, @Cognome, @Sesso);";
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", password);
                    cmd.Parameters.AddWithValue("@Nome", nome);
                    cmd.Parameters.AddWithValue("@Cognome", cognome);
                    cmd.Parameters.AddWithValue("@Sesso", sesso);

                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.ExecuteNonQuery();


                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message} - Stack; {ex.StackTrace}");
            }
            finally
            {
                if (conn != null)
                {
                    conn.Dispose();
                }
            }
        }

        public static Cliente login(string username, string password)
        {
            var connection = new SqlConnection(CONNECTION_STRING);
            Cliente u = null;

            try
            {
                connection.Open();

                using (SqlCommand cmd = connection.CreateCommand())
                {
                    cmd.CommandText = "select * from Cliente where Username = @Username and Password = @Password";
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", password);
                    cmd.CommandType = System.Data.CommandType.Text;


                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            u = new Cliente(dr.GetInt64(0), dr.GetString(1), dr.GetString(2), dr.GetString(3), dr.GetString(4), dr.GetString(5));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message} - Stack; {ex.StackTrace}");
            }
            finally
            {
                if (connection != null)
                {
                    connection.Dispose();
                    connection = null;
                }
            }
            return u;
        }
    }

}

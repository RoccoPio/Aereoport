﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aereoporto
{
    internal class Aereo
    {
        public long ID_aereo;
        public string Parte_da;
        public string Arriva_a;
        public string Ora_par;
        public string Ora_arri;

        public Aereo(string parte_da, string arriva_a, string ora_par, string ora_arri)
        {
            Parte_da = parte_da;
            Arriva_a = arriva_a;
            Ora_par = ora_par;
            Ora_arri = ora_arri;
        }

        public Aereo(long iD_aereo, string parte_da, string arriva_a, string ora_par, string ora_arri)
        {
            ID_aereo = iD_aereo;
            Parte_da = parte_da;
            Arriva_a = arriva_a;
            Ora_par = ora_par;
            Ora_arri = ora_arri;
        }

        public override string ToString()
        {
            return "--------------------------------- \n"  +
                   $"ID_aereo: {ID_aereo} \n" +
                   $"Parte da: {Parte_da} \n" +
                   $"Arriva a: {Arriva_a}  \n" +
                   $"Ora partenza: {Ora_par}\n" +
                   $"Ora arrrivo: {Ora_arri} \n" +
                   "---------------------------------";
        }

        const string CONNECTION_STRING = "Server=LAPTOP-VC79DN9U\\MSSQLSERVER01;Initial Catalog=db_aereoC; Trusted_Connection=True";
        

        public static List<Aereo> GetAereoList()
        {
           SqlConnection conn = new SqlConnection(CONNECTION_STRING);
            List<Aereo> lista= new List<Aereo>();

            try
            {
                conn.Open();

                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "select * from Aereo";
                    cmd.CommandType = System.Data.CommandType.Text;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            Aereo ae = new Aereo(dr.GetInt64(0), dr.GetString(1), dr.GetString(2), dr.GetString(3), dr.GetString(4));

                            lista.Add(ae);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message} - Stack; {ex.StackTrace}");
            }
            finally
            {
                if (conn != null)
                {
                    conn.Dispose();
                    conn = null;
                }
            }
            return lista;


        }


    }
}

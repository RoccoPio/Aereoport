﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aereoporto
{
    internal class Biglietto
    {

        public string nome, cognome, da, a, giorno, parte_da, arriva_a, ora_arr, ora_par;

        public Biglietto(string nome, string cognome, string da, string a, string giorno, string parte_da, string arriva_a, string ora_arr, string ora_par)
        {
            this.nome = nome;
            this.cognome = cognome;
            this.da = da;
            this.a = a;
            this.giorno = giorno;
            this.parte_da = parte_da;
            this.arriva_a = arriva_a;
            this.ora_arr = ora_arr;
            this.ora_par = ora_par;
        }

        public override string ToString()
        {
            return  $"Nome: {nome} \n" +
                    $"Cognome: {cognome} \n" +
                    $"Da: {da}  \n" +
                    $"A: {a}\n" +
                    $"Giorno: {giorno}\n" +
                    $"Parte Da: {parte_da}\n" +
                    $"Arriva a: {arriva_a}\n" +
                    $"Ora arrivo: {ora_arr}\n" +
                    $"Ora partenza: {ora_par} \n" +
                   "**********************************";
        }
        const string CONNECTION_STRING = "Server=LAPTOP-VC79DN9U\\MSSQLSERVER01;Initial Catalog=db_aereoC; Trusted_Connection=True";



        public static List<Biglietto> AddTicket(Cliente u)
        {
            var connection = new SqlConnection(CONNECTION_STRING);
            List<Biglietto> listab = new List<Biglietto>();

            try
            {
                connection.Open();

                using (SqlCommand cmd = connection.CreateCommand())
                {
                    cmd.CommandText = "Select Nome, Cognome, Da, A, Giorno, Parte_da, Arriva_a, Ora_par, Ora_arr from Cliente inner join Volo on Cliente.ID_cliente = Volo.ID_cliente inner join Aereo on Volo.ID_aereo = Aereo.ID_aereo where Cliente.ID_cliente = @ID_cliente";
                    cmd.Parameters.AddWithValue("@ID_cliente", u.idcliente);
                    cmd.CommandType = System.Data.CommandType.Text;


                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            Biglietto b = new Biglietto(dr.GetString(0), dr.GetString(1), dr.GetString(2), dr.GetString(3), dr.GetString(4), dr.GetString(5), dr.GetString(6), dr.GetString(7), dr.GetString(8));

                            listab.Add(b);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message} - Stack; {ex.StackTrace}");
            }
            finally
            {
                if (connection != null)
                {
                    connection.Dispose();
                    connection = null;
                }
            }
            return listab;
        }
    }


}

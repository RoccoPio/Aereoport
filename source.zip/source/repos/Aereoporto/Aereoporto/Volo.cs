﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aereoporto
{
    internal class Volo
    {
        public long ID_volo;
        public string Da;
        public string A;
        public string Giorno;
        public long ID_aereo;

        public Volo(string da, string a, string giorno, long iD_aereo)
        {
            Da = da;
            A = a;
            Giorno = giorno;
            ID_aereo = iD_aereo;
        }

        public Volo(long iD_volo, string da, string a, string giorno, long iD_aereo)
        {
            ID_volo = iD_volo;
            Da = da;
            A = a;
            Giorno = giorno;
            ID_aereo = iD_aereo;
        }


        const string CONNECTION_STRING = "Server=LAPTOP-VC79DN9U\\MSSQLSERVER01;Initial Catalog=db_aereoC; Trusted_Connection=True";
        SqlConnection conn = new SqlConnection(CONNECTION_STRING);

        public static void AddPren(Cliente u, long id_aereo, string da, string a, string giorno)
        {

            SqlConnection conn = new SqlConnection(CONNECTION_STRING);

            try
            {
                conn.Open();
                using (SqlCommand cmd = conn.CreateCommand())
                {

                    cmd.CommandText = "Insert into Volo (Da, A, Giorno, ID_aereo, ID_cliente) values (@DA, @A, @Giorno, @ID_aereo, @ID_cliente)";
                    cmd.Parameters.AddWithValue("@DA", da);
                    cmd.Parameters.AddWithValue("@A", a);
                    cmd.Parameters.AddWithValue("@Giorno", giorno);
                    cmd.Parameters.AddWithValue("@ID_aereo", id_aereo);
                    cmd.Parameters.AddWithValue("@ID_cliente", u.idcliente);

                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.ExecuteNonQuery();

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message} - Stack; {ex.StackTrace}");
            }
            finally
            {
                if (conn != null)
                {
                    conn.Dispose();
                }
            }
        }

    }
}

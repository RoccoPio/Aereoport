﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aereoporto
{
    internal class Main1
    {
        public static Cliente Login_Signup()
        {
            string menu = "--- Login | Setup ---" +
                          "\n 1) Login" +
                          "\n 2) Signup" +
                          "\n ----------------------";
            Console.WriteLine(menu);
            int risp = int.Parse(Console.ReadLine());

            Cliente u_find = null;

            do
            {
                switch (risp)
                {

                    case 1:
                        {
                            Console.WriteLine("-------------------------------------- \n" +
                                              "Inserisci Username");
                            string username = Console.ReadLine();
                            Console.WriteLine("Inserisci Password");
                            string password = Console.ReadLine();

                            u_find = Cliente.login(username, password);
                            break;
                        }

                    case 2:
                        {
                            Console.WriteLine("Nome:");
                            string nome = Console.ReadLine();
                            Console.WriteLine("Cognome:");
                            string cognome = Console.ReadLine();
                            Console.WriteLine("Username:");
                            string username = Console.ReadLine();
                            Console.WriteLine("Password:");
                            string password = Console.ReadLine();
                            Console.WriteLine("Sesso:");
                            string sesso = Console.ReadLine();
                            u_find = new Cliente(username, password, nome, cognome, sesso);
                            u_find.signup(u_find);

                            break;
                        }
                }
            } while (u_find == null);
            return u_find;
        }
        public static void Main(string[] args)

        {
            Cliente u_find = Login_Signup();

            List<Aereo> lista = Aereo.GetAereoList();

            Console.WriteLine("--------------------------------\n" +
                              "1) Prenota biglietto \n" +
                              "2) Vedi biglietto/i ordinati \n" +
                              "3) Esci dal menu \n" +
                              "--------------------------------");

            int risp1 = int.Parse(Console.ReadLine());

            do
            {
                switch (risp1)
                {

                    case 1:
                        {
                            Console.WriteLine("Dove vuoi andare?");
                            string a = Console.ReadLine();
                            Console.WriteLine("Da dove vuoi partire?");
                            string da = Console.ReadLine();
                            Console.WriteLine("Che giorno vuoi partire? (Inserire data gg/mm/aaaa)");
                            string giorno = Console.ReadLine();
                            Console.WriteLine();

                            Console.WriteLine("Scegli tra gli aerei disponibili e digita il suo id:");

                            foreach (var aereo in lista)
                            {
                                if (aereo.Arriva_a.Equals(a) && aereo.Parte_da.Equals(da))
                                {
                                    Console.WriteLine(aereo.ToString());
                                }
                            }
                            long id = Convert.ToInt64(Console.ReadLine());

                            Volo.AddPren(u_find, id, da, a, giorno);
                            break;
                        }

                    case 2:
                        {
                            Console.WriteLine("--------Elenco biglietti/o--------\n");

                            List<Biglietto> listab = Biglietto.AddTicket(u_find);

                            foreach (var ticket in listab)
                            {
                                Console.WriteLine(ticket.ToString());
                            }
                            break;
                        }
                }
            } while (risp1 == 3) ;

        }
    }
}

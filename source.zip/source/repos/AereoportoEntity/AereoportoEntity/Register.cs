﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AereoportoEntity
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        db_aereoCEntities db = new db_aereoCEntities();
        
        private void button1_Click(object sender, EventArgs e)
        {
            
            Cliente c = new Cliente();
            if(textUserlog.Text != "" || Textpasslog.Text != "" || textNome.Text != "" || textCognome.Text != "" || textSesso.Text != "")
            {
                c.Username = textUserlog.Text;
                c.Password = Textpasslog.Text;
                c.Nome= textNome.Text;
                c.Cognome= textCognome.Text;
                c.Sesso= textSesso.Text;            
                db.Cliente.Add(c);
                long ID_cliente = c.ID_cliente;

                db.SaveChanges();

                MessageBox.Show("Registrato con successo");
                Home home = new Home(c);
                this.Hide();
                home.Show();

            }
            else
            {
                MessageBox.Show("Campi vuoti","Errore" , MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

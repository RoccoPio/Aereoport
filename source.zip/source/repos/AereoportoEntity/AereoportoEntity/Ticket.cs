﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AereoportoEntity
{
    public partial class Ticket : UserControl
    {

        long Id_volo;
        string da;
        string a;
        string giorno;
        long iD_aereo;
        string Nome_Cognome;

        public Ticket()
        {
            InitializeComponent();
        }

        public Ticket(long ID, string Da, string A, string Giorno, long ID_aereo, string Nome_Cognome)
        {

            this.Id_volo = ID;
            this.da = Da;
            this.a = A;
            this.giorno = Giorno;
            this.iD_aereo= ID_aereo;
            this.Nome_Cognome= Nome_Cognome;

            InitializeComponent();
        }

        private void Ticket_Load(object sender, EventArgs e)
        {
            ID_volo.Text = Id_volo.ToString();
            Da.Text = da;
            A.Text = a;
            Giorno.Text = giorno;
            Cliente.Text = Nome_Cognome;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            using(db_aereoCEntities db = new db_aereoCEntities())
            {
               var stmodel = db.Volo.Where(x => x.ID_volo == Id_volo).FirstOrDefault();
               db.Volo.Remove(stmodel);
                db.SaveChanges();
            }
            this.Controls.Clear();
            this.Dispose();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AereoportoEntity
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        
        

        private void btnAccedi_Click(object sender, EventArgs e)
        {            
            
            string username = textUserlog.Text;
            string password = Textpasslog.Text;
            long ID_cliente = 0;
            Cliente c = null;
            using (db_aereoCEntities dbcontext = new db_aereoCEntities())
            {
                
                try
                {
                    c = dbcontext.Cliente.First(a => a.Username == username && a.Password == password);
                    ID_cliente = c.ID_cliente;
                    
                }
                catch (Exception ex)
                {

                }
                

                if (c != null)
                {
                    MessageBox.Show("Benvenuto " + c.Username);
                    
                    Home home = new Home(c);
                    this.Hide();
                    home.Show();
                }
                else
                { 
                    MessageBox.Show("Erorre","Riprova", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    //textUserlog.Text = "";
                    //Textpasslog.Text = "";
                }
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            Register register = new Register();
            this.Hide();
            register.Show();    
        }
    }
}

﻿namespace AereoportoEntity
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.panelMenu = new System.Windows.Forms.Panel();
            this.btnBiglietti = new System.Windows.Forms.Button();
            this.btnPrenota = new System.Windows.Forms.Button();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.paneltitle = new System.Windows.Forms.Panel();
            this.labelTitle = new System.Windows.Forms.Label();
            this.panelDesktop = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panelMenu.SuspendLayout();
            this.panelLogo.SuspendLayout();
            this.paneltitle.SuspendLayout();
            this.panelDesktop.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.DarkCyan;
            this.panelMenu.Controls.Add(this.btnBiglietti);
            this.panelMenu.Controls.Add(this.btnPrenota);
            this.panelMenu.Controls.Add(this.panelLogo);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(182, 551);
            this.panelMenu.TabIndex = 0;
            // 
            // btnBiglietti
            // 
            this.btnBiglietti.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnBiglietti.FlatAppearance.BorderSize = 0;
            this.btnBiglietti.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBiglietti.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBiglietti.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnBiglietti.Image = ((System.Drawing.Image)(resources.GetObject("btnBiglietti.Image")));
            this.btnBiglietti.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBiglietti.Location = new System.Drawing.Point(0, 306);
            this.btnBiglietti.Name = "btnBiglietti";
            this.btnBiglietti.Size = new System.Drawing.Size(182, 245);
            this.btnBiglietti.TabIndex = 1;
            this.btnBiglietti.Text = "TICKET";
            this.btnBiglietti.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBiglietti.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnBiglietti.UseVisualStyleBackColor = true;
            this.btnBiglietti.Click += new System.EventHandler(this.btnBiglietti_Click);
            // 
            // btnPrenota
            // 
            this.btnPrenota.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPrenota.FlatAppearance.BorderSize = 0;
            this.btnPrenota.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrenota.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrenota.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnPrenota.Image = ((System.Drawing.Image)(resources.GetObject("btnPrenota.Image")));
            this.btnPrenota.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPrenota.Location = new System.Drawing.Point(0, 80);
            this.btnPrenota.Name = "btnPrenota";
            this.btnPrenota.Size = new System.Drawing.Size(182, 226);
            this.btnPrenota.TabIndex = 0;
            this.btnPrenota.Text = "PRENOTA  VOLO";
            this.btnPrenota.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPrenota.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnPrenota.UseVisualStyleBackColor = true;
            this.btnPrenota.Click += new System.EventHandler(this.btnPrenota_Click);
            // 
            // panelLogo
            // 
            this.panelLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.panelLogo.Controls.Add(this.label1);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(182, 80);
            this.panelLogo.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "AEREOPORT";
            // 
            // paneltitle
            // 
            this.paneltitle.BackColor = System.Drawing.Color.DarkCyan;
            this.paneltitle.Controls.Add(this.labelTitle);
            this.paneltitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.paneltitle.Location = new System.Drawing.Point(182, 0);
            this.paneltitle.Name = "paneltitle";
            this.paneltitle.Size = new System.Drawing.Size(745, 80);
            this.paneltitle.TabIndex = 1;
            // 
            // labelTitle
            // 
            this.labelTitle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.ForeColor = System.Drawing.Color.White;
            this.labelTitle.Location = new System.Drawing.Point(318, 27);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(80, 28);
            this.labelTitle.TabIndex = 1;
            this.labelTitle.Text = "HOME";
            // 
            // panelDesktop
            // 
            this.panelDesktop.Controls.Add(this.flowLayoutPanel1);
            this.panelDesktop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDesktop.Location = new System.Drawing.Point(182, 80);
            this.panelDesktop.Name = "panelDesktop";
            this.panelDesktop.Size = new System.Drawing.Size(745, 471);
            this.panelDesktop.TabIndex = 2;
            this.panelDesktop.Paint += new System.Windows.Forms.PaintEventHandler(this.panelDesktop_Paint);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(2, 3);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(742, 467);
            this.flowLayoutPanel1.TabIndex = 0;
            this.flowLayoutPanel1.Visible = false;
            this.flowLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(927, 551);
            this.Controls.Add(this.panelDesktop);
            this.Controls.Add(this.paneltitle);
            this.Controls.Add(this.panelMenu);
            this.Name = "Home";
            this.Text = "Home";
            this.panelMenu.ResumeLayout(false);
            this.panelLogo.ResumeLayout(false);
            this.panelLogo.PerformLayout();
            this.paneltitle.ResumeLayout(false);
            this.paneltitle.PerformLayout();
            this.panelDesktop.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Button btnPrenota;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.Button btnBiglietti;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel paneltitle;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Panel panelDesktop;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
    }
}
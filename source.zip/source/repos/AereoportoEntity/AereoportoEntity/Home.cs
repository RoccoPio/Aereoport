﻿using AereoportoEntity.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AereoportoEntity
{
    public partial class Home : Form
    {

        private Form activeForm;
        private Prenota1 p;
        
        Cliente c;

        public Home(Cliente valore)
        {
            InitializeComponent();
            c = valore;
        }

        private void panelDesktop_Paint(object sender, PaintEventArgs e)
        {

        }


        private void OpenChildForm(Form childForm, object btnSender)
        {
            if(activeForm!= null)
            {
                activeForm.Close();
            }
            activeForm= childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle= FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;    
            this.panelDesktop.Controls.Add(childForm);
            this.panelDesktop.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            labelTitle.Text = childForm.Text;


        }

        private void btnPrenota_Click(object sender, EventArgs e)
        {
            flowLayoutPanel1.Visible = false;
            p = new Prenota1(c);
            OpenChildForm(p, sender);

        }

        private void btnBiglietti_Click(object sender, EventArgs e)
        {
            p.Hide();
            flowLayoutPanel1.Visible = true;

            using (db_aereoCEntities db = new db_aereoCEntities())
            {
                List<Volo> listvolo = db.Volo.Where(x => x.ID_cliente == c.ID_cliente).ToList();

                List<Ticket> listticket = new List<Ticket>();



                foreach (var volo in listvolo)
                {
                    Ticket t = new Ticket(volo.ID_volo, volo.DA, volo.A, volo.Giorno, volo.ID_aereo, c.Nome + c.Cognome);
                    listticket.Add(t);
                }


                flowLayoutPanel1.Controls.Clear();
                foreach (var ticket in listticket)
                {
                    flowLayoutPanel1.Controls.Add(ticket);
                }


            }

            
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace AereoportoEntity.Forms
{
    public partial class Prenota1 : Form
    {

        Volo volo = new Volo();
        Cliente c;
        public Prenota1(Cliente valore)
        {
            InitializeComponent();
            c = valore;
        }

        private void button1_Click(object sender, EventArgs e)
        {
                using (db_aereoCEntities db = new db_aereoCEntities())
                {
                    dataGridView1.DataSource =db.Aereo.Where(x => x.Parte_da == textParti_da.Text && x.Arriva_a == textArriva_a.Text).ToList();
                }
        }


        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            textGiorno.Text = monthCalendar1.SelectionRange.Start.ToShortDateString();
        }


        private void button2_Click(object sender, EventArgs e)
        {
            if (textParti_da.Text == "" || textArriva_a.Text == "" || textGiorno.Text == "" || textID_aereo.Text == "")
            {
                MessageBox.Show("!! Ci sono campi vuoti !!", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {

                using (db_aereoCEntities db = new db_aereoCEntities())
                {
                    Volo b = new Volo();
                    b.DA = textParti_da.Text;
                    b.A = textArriva_a.Text;
                    b.Giorno= textGiorno.Text;
                    b.ID_aereo = long.Parse(textID_aereo.Text);
                    b.ID_cliente = c.ID_cliente;
                    db.Volo.Add(b);

                    db.SaveChanges();

                    MessageBox.Show("Prenotato con successo");
                }



            }
        }


    }
}

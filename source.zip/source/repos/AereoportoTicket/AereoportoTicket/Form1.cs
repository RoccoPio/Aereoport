using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace AereoportoTicket
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


        }

        const string CONNECTION_STRING = "Server=LAPTOP-VC79DN9U\\MSSQLSERVER01;Initial Catalog=db_aereoC; Trusted_Connection=True";
        SqlConnection conn = new SqlConnection(CONNECTION_STRING);


        private void RegisterButton_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "" && txtpassword.Text == "" && textNome.Text == "" && txtCognome.Text == "" && txtSesso.Text == "")
            {
                MessageBox.Show("!! Ci sono campi vuoti !!", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                conn.Open();
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "INSERT INTO Cliente (Username, Password, Nome, Cognome, Sesso) VALUES (@Username, @Password, @Nome, @Cognome, @Sesso);";
                    cmd.Parameters.AddWithValue("@Username", txtUsername.Text);
                    cmd.Parameters.AddWithValue("@Password", txtpassword.Text);
                    cmd.Parameters.AddWithValue("@Nome", textNome.Text);
                    cmd.Parameters.AddWithValue("@Cognome", txtCognome.Text);
                    cmd.Parameters.AddWithValue("@Sesso", txtSesso.Text);

                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("Registrazione effettuata");

                    Prenotazione prenotazione = new Prenotazione(txtUsername);
                    prenotazione.Show();
                    this.Hide();

                }
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtUsername.Text = "";
            txtpassword.Text = "";
            textNome.Text = "";
            txtCognome.Text = "";
            txtSesso.Text = "";
        }

        private void label11_Click(object sender, EventArgs e)
        {
            new FormLogin().Show();
            this.Hide();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
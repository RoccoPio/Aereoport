﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AereoportoTicket
{
    public partial class Prenotazione : Form
    {
        TextBox username;
        public Prenotazione(TextBox valore)
        {
            InitializeComponent();
            username = valore;
            
        }



        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void txtda_TextChanged(object sender, EventArgs e)
        {

        }


        private void txtda_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        
        }

        private void btviewvoli_Click(object sender, EventArgs e)
        {
            const string CONNECTION_STRING = "Server=LAPTOP-VC79DN9U\\MSSQLSERVER01;Initial Catalog=db_aereoC; Trusted_Connection=True";
            SqlConnection conn = new SqlConnection(CONNECTION_STRING);

            conn.Open();

            string query = "Select * from Aereo where Parte_da = '" + txtda.Text + "' and Arriva_a = '" + txta.Text + "'";
            SqlCommand cmd = new SqlCommand(query, conn);

            var reader = cmd.ExecuteReader();

            DataTable table = new DataTable();
            table.Load(reader);

            dataGridView1.DataSource = table;

            conn.Close();
        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            const string CONNECTION_STRING = "Server=LAPTOP-VC79DN9U\\MSSQLSERVER01;Initial Catalog=db_aereoC; Trusted_Connection=True";
            SqlConnection conn = new SqlConnection(CONNECTION_STRING);

            if(txtda.Text == "" || txta.Text == "" || txtidaereo.Text == "")
            {
                MessageBox.Show("!! Ci sono campi vuoti !!", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                conn.Open();
                using (SqlCommand cmd = conn.CreateCommand())
                {

                    cmd.CommandText = "Insert into Volo (DA, A, Giorno, ID_aereo, ID_cliente) values (@DA, @A, @Giorno, @ID_aereo, (select ID_cliente from Cliente where Username = @Username))";
                    cmd.Parameters.AddWithValue("@DA", txtda.Text);
                    cmd.Parameters.AddWithValue("@A", txta.Text);
                    cmd.Parameters.AddWithValue("@Giorno", txtdate.Text);
                    cmd.Parameters.AddWithValue("@ID_aereo", txtidaereo.Text);
                    cmd.Parameters.AddWithValue("@Username", username.Text);

                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.ExecuteNonQuery();

                    conn.Close();

                    MessageBox.Show("Prenotazione Effettuata");

                    
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Biglietto biglietto = new Biglietto(username);
            biglietto.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellContentClick_2(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

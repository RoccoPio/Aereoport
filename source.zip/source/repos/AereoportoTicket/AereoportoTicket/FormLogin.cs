﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace AereoportoTicket
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        const string CONNECTION_STRING = "Server=LAPTOP-VC79DN9U\\MSSQLSERVER01;Initial Catalog=db_aereoC; Trusted_Connection=True";
        SqlConnection conn = new SqlConnection(CONNECTION_STRING);


        private void AccediButton_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Sono qui");

            String username, password;
            
            username = txtUserlog.Text;
            password = txtpasslog.Text;
            

            try
            {

                string query = "select * from Cliente where Username = '" + txtUserlog.Text + "' and Password = '" + txtpasslog.Text + "'";

                SqlDataAdapter sda = new SqlDataAdapter(query, conn);

                DataTable dtable = new DataTable();

                sda.Fill(dtable);

                if(dtable.Rows.Count > 0 ) 
                {
                    username = txtUserlog.Text;
                    password = txtpasslog.Text;

                    Prenotazione prenotazione = new Prenotazione(txtUserlog);
                    prenotazione.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("!!Username o Password non validi!!", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtUserlog.Clear();
                    txtpasslog.Clear();

                    txtUserlog.Focus();
                }
            }
            catch
            {
                MessageBox.Show("Errore");

            }
            finally
            {
                conn.Close();
            }
                
        }


        private void button1_Click(object sender, EventArgs e)
        {
            txtUserlog.Clear();
            txtpasslog.Clear();
            txtUserlog.Focus();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }
    }
}

﻿namespace AereoportoTicket
{
    partial class Prenotazione
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtda = new System.Windows.Forms.TextBox();
            this.txta = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtdate = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btviewvoli = new System.Windows.Forms.Button();
            this.txtidaereo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(73, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(474, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "PRENOTA IL TUO BIGLIETTO!!!";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(37, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "PARTI DA:";
            // 
            // txtda
            // 
            this.txtda.AcceptsTab = true;
            this.txtda.Location = new System.Drawing.Point(23, 123);
            this.txtda.Name = "txtda";
            this.txtda.Size = new System.Drawing.Size(121, 23);
            this.txtda.TabIndex = 5;
            this.txtda.TextChanged += new System.EventHandler(this.txtda_TextChanged_1);
            // 
            // txta
            // 
            this.txta.AcceptsTab = true;
            this.txta.Location = new System.Drawing.Point(426, 123);
            this.txta.Name = "txta";
            this.txta.Size = new System.Drawing.Size(121, 23);
            this.txta.TabIndex = 7;
            this.txta.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(439, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "ARRIVI A:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // txtdate
            // 
            this.txtdate.AcceptsTab = true;
            this.txtdate.Location = new System.Drawing.Point(190, 203);
            this.txtdate.Name = "txtdate";
            this.txtdate.Size = new System.Drawing.Size(170, 23);
            this.txtdate.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(160, 163);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(226, 25);
            this.label4.TabIndex = 8;
            this.label4.Text = "IL GIORNO(gg/mm/aaaa):";
            // 
            // btviewvoli
            // 
            this.btviewvoli.ForeColor = System.Drawing.Color.Black;
            this.btviewvoli.Location = new System.Drawing.Point(238, 275);
            this.btviewvoli.Name = "btviewvoli";
            this.btviewvoli.Size = new System.Drawing.Size(75, 23);
            this.btviewvoli.TabIndex = 11;
            this.btviewvoli.Text = "Mostra voli";
            this.btviewvoli.UseVisualStyleBackColor = true;
            this.btviewvoli.Click += new System.EventHandler(this.btviewvoli_Click);
            // 
            // txtidaereo
            // 
            this.txtidaereo.AcceptsTab = true;
            this.txtidaereo.Location = new System.Drawing.Point(190, 509);
            this.txtidaereo.Name = "txtidaereo";
            this.txtidaereo.Size = new System.Drawing.Size(170, 23);
            this.txtidaereo.TabIndex = 13;
            this.txtidaereo.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(173, 468);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(213, 25);
            this.label5.TabIndex = 12;
            this.label5.Text = "Digitare ID aereo scelto:";
            this.label5.Click += new System.EventHandler(this.label5_Click_1);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button1.Location = new System.Drawing.Point(238, 549);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "Prenota";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Location = new System.Drawing.Point(214, 591);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(126, 23);
            this.button2.TabIndex = 15;
            this.button2.Text = "Mostra Biglietto/i";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(23, 319);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.Size = new System.Drawing.Size(547, 129);
            this.dataGridView1.TabIndex = 16;
            // 
            // Prenotazione
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(594, 641);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtidaereo);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btviewvoli);
            this.Controls.Add(this.txtdate);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txta);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtda);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "Prenotazione";
            this.Text = "Prenotazione";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtda;
        private TextBox txta;
        private Label label3;
        private TextBox txtdate;
        private Label label4;
        private Button btviewvoli;
        private TextBox txtidaereo;
        private Label label5;
        private Button button1;
        private Button button2;
        private DataGridView dataGridView1;
    }
}
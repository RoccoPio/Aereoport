﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AereoportoTicket
{
    public partial class Biglietto : Form
    {
        TextBox username1;
        public Biglietto(TextBox valore)
        {
            InitializeComponent();
            username1 = valore;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            const string CONNECTION_STRING = "Server=LAPTOP-VC79DN9U\\MSSQLSERVER01;Initial Catalog=db_aereoC; Trusted_Connection=True";
            SqlConnection conn = new SqlConnection(CONNECTION_STRING);

            conn.Open();

            string query = "Select * from Volo where ID_cliente = (Select ID_cliente from Cliente where Username = '" + username1.Text + "')";
            SqlCommand cmd = new SqlCommand(query, conn);

            var reader = cmd.ExecuteReader();

            DataTable table = new DataTable();
            table.Load(reader);

            dataGridView1.DataSource = table;

            conn.Close();
        }


        private void button2_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
